/**
 * GODDATAX iOS - Free Fire OB56 Native Touch Hook (.dylib)
 * 
 * Modul Tweak Hook Sumbu X & Y untuk Free Fire iOS.
 * Tweak ini di-inject langsung ke dalam file FreeFire.ipa.
 * 
 * Cara kerja:
 * 1. Meng-hook event sentuhan Unity/UIKit saat pemain menggeser layar di Free Fire.
 * 2. Mengambil rasio Sumbu X dan Y yang telah Anda atur di aplikasi GodDataX.
 * 3. Melipatgandakan delta pergerakan sentuhan secara real-time, sehingga:
 *    -> Walaupun sensitivitas di dalam game Free Fire bernilai 0,
 *       layar tetap berputar kencang dan tarikan drag shot ke kepala musuh sangat enteng!
 */

#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <Foundation/Foundation.h>

// Struktur Konfigurasi Sumbu X & Y
struct GDXTouchConfig {
    BOOL isEnabled;
    BOOL isCompetitiveMode;
    float sensX;
    float sensY;
    float responseSpeed;
};

static struct GDXTouchConfig currentConfig = {
    .isEnabled = YES,
    .isCompetitiveMode = YES,
    .sensX = 1.80f,
    .sensY = 3.20f,
    .responseSpeed = 1.0f
};

// Fungsi pembaca file konfigurasi dari GodDataX
static void loadGDXConfig(void) {
    NSArray *paths = @[
        @"/var/mobile/Documents/GodDataX_TouchConfig.json",
        [NSTemporaryDirectory() stringByAppendingPathComponent:@"GodDataX_TouchConfig.json"],
        [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject stringByAppendingPathComponent:@"GodDataX_TouchConfig.json"]
    ];
    
    for (NSString *path in paths) {
        if ([[NSFileManager defaultManager] fileExistsAtPath:path]) {
            NSData *data = [NSData dataWithContentsOfFile:path];
            if (data) {
                NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                if (dict && [dict isKindOfClass:[NSDictionary class]]) {
                    if (dict[@"enabled"]) currentConfig.isEnabled = [dict[@"enabled"] boolValue];
                    if (dict[@"sensitivityX"]) currentConfig.sensX = [dict[@"sensitivityX"] floatValue];
                    if (dict[@"sensitivityY"]) currentConfig.sensY = [dict[@"sensitivityY"] floatValue];
                    if (dict[@"responseSpeed"]) currentConfig.responseSpeed = [dict[@"responseSpeed"] floatValue];
                    if (dict[@"gameMode"]) {
                        NSString *mode = [dict[@"gameMode"] description];
                        currentConfig.isCompetitiveMode = [mode isEqualToString:@"Competitive"];
                    }
                    NSLog(@"[GodDataX Hook] Loaded Config: enabled=%d, mode=%s, X=%.2f, Y=%.2f",
                          currentConfig.isEnabled,
                          currentConfig.isCompetitiveMode ? "Competitive" : "Balance",
                          currentConfig.sensX,
                          currentConfig.sensY);
                    return;
                }
            }
        }
    }
}

// Swizzle implementation untuk UITouch locationInView
static CGPoint (*orig_locationInView)(id, SEL, UIView *);

static CGPoint hook_locationInView(UITouch *self, SEL _cmd, UIView *view) {
    CGPoint orig = orig_locationInView(self, _cmd, view);
    
    if (!currentConfig.isEnabled) {
        return orig;
    }
    
    CGPoint prev = [self previousLocationInView:view];
    
    // Hitung pergeseran delta sentuhan
    CGFloat dx = orig.x - prev.x;
    CGFloat dy = orig.y - prev.y;
    
    // Lipatgandakan delta pergerakan dengan sensitivitas Sumbu X dan Y
    // Mode Competitive: Respons seketika (instant boost) tanpa interpolasi delay
    // Mode Balance: Pergerakan halus stabil dengan kontrol termal
    CGFloat multX = currentConfig.isCompetitiveMode ? (currentConfig.sensX - 1.0f) : (currentConfig.sensX - 1.0f) * 0.90f;
    CGFloat multY = currentConfig.isCompetitiveMode ? (currentConfig.sensY - 1.0f) : (currentConfig.sensY - 1.0f) * 0.90f;
    
    CGFloat amplifiedDx = dx * multX;
    CGFloat amplifiedDy = dy * multY;
    
    return CGPointMake(orig.x + amplifiedDx, orig.y + amplifiedDy);
}

static NSTimeInterval gGameLaunchTime = 0;

static void updateGamePlaytimeStats(void) {
    if (gGameLaunchTime <= 0) return;
    NSTimeInterval sessionSeconds = [[NSDate date] timeIntervalSince1970] - gGameLaunchTime;
    if (sessionSeconds <= 0) return;
    
    NSArray *paths = @[
        @"/var/mobile/Documents/GodDataX_GameStats.json",
        [NSTemporaryDirectory() stringByAppendingPathComponent:@"GodDataX_GameStats.json"]
    ];
    
    double previousTotal = 0;
    for (NSString *p in paths) {
        if ([[NSFileManager defaultManager] fileExistsAtPath:p]) {
            NSData *d = [NSData dataWithContentsOfFile:p];
            if (d) {
                NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:d options:0 error:nil];
                if (dict && dict[@"playtimeSeconds"]) {
                    previousTotal = [dict[@"playtimeSeconds"] doubleValue];
                    break;
                }
            }
        }
    }
    
    double newTotal = previousTotal + 5.0;
    NSDictionary *stats = @{
        @"bundleId": @"com.dts.freefireth",
        @"playtimeSeconds": @(newTotal),
        @"sessionSeconds": @(sessionSeconds),
        @"lastActive": @([[NSDate date] timeIntervalSince1970])
    };
    NSData *data = [NSJSONSerialization dataWithJSONObject:stats options:0 error:nil];
    if (data) {
        for (NSString *p in paths) {
            [data writeToFile:p atomically:YES];
        }
    }
}

// Inisialisasi Hook saat dylib dimuat oleh Free Fire
__attribute__((constructor))
static void initializeGodDataXHook(void) {
    @autoreleasepool {
        NSLog(@"[GodDataX OB56] Initializing Native Free Fire Touch Hook...");
        
        gGameLaunchTime = [[NSDate date] timeIntervalSince1970];
        loadGDXConfig();
        
        // Timer polling konfigurasi setiap 5 detik agar perubahan slider di GodDataX langsung diterapkan
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0), ^{
            while (1) {
                sleep(5);
                loadGDXConfig();
                updateGamePlaytimeStats();
            }
        });
        
        // Swizzle method -[UITouch locationInView:]
        Class uiTouchClass = [UITouch class];
        SEL selector = @selector(locationInView:);
        Method origMethod = class_getInstanceMethod(uiTouchClass, selector);
        
        if (origMethod) {
            orig_locationInView = (CGPoint (*)(id, SEL, UIView *))method_getImplementation(origMethod);
            method_setImplementation(origMethod, (IMP)hook_locationInView);
            NSLog(@"[GodDataX OB56] -[UITouch locationInView:] successfully hooked!");
        } else {
            NSLog(@"[GodDataX OB56] Error: Failed to find -[UITouch locationInView:]");
        }
        
        // Tampilkan subtle banner HUD di atas game
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            UIWindow *keyWindow = nil;
            for (UIWindow *w in [UIApplication sharedApplication].windows) {
                if (w.isKeyWindow) { keyWindow = w; break; }
            }
            if (keyWindow) {
                UILabel *badge = [[UILabel alloc] initWithFrame:CGRectMake(20, 40, 180, 24)];
                badge.text = @" GDX OB56 HOOK ACTIVE ";
                badge.textColor = [UIColor whiteColor];
                badge.backgroundColor = [UIColor colorWithRed:1.0 green:0.12 blue:0.15 alpha:0.8];
                badge.font = [UIFont boldSystemFontOfSize:11];
                badge.layer.cornerRadius = 6;
                badge.layer.masksToBounds = YES;
                badge.textAlignment = NSTextAlignmentCenter;
                [keyWindow addSubview:badge];
                
                // Hilang otomatis setelah 4 detik
                [UIView animateWithDuration:0.8 delay:4.0 options:0 animations:^{
                    badge.alpha = 0.0;
                } completion:^(BOOL finished) {
                    [badge removeFromSuperview];
                }];
            }
        });
    }
}

#!/bin/bash
set -e

echo "=== 1. Checking Project ==="
ls -la

echo "=== 2. Building GodDataX ==="
xcodebuild clean build \
  -project GodDataX.xcodeproj \
  -scheme GodDataX \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  AD_HOC_CODE_SIGNING_ALLOWED=YES

echo "=== 3. Packaging IPA ==="
mkdir -p Payload
APP_PATH=$(find build -name "GodDataX.app" -type d | head -n 1)
echo "Found app at: $APP_PATH"
cp -r "$APP_PATH" Payload/
zip -qr GodDataX_OB56.ipa Payload
ls -lh GodDataX_OB56.ipa
echo "=== Done! ==="
